import React from "react"
import ReactDOM from "react-dom"
import Observable from "./Observable"

ReactDOM.render(
  <React.StrictMode>
    <Observable />
  </React.StrictMode>,
  document.getElementById("root")
)
